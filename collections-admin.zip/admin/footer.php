<footer class="footer">
                                        <div class="container">
                                            <nav>
                                                
                                                <p class="copyright text-center">
                                                   &copy WEBEX TECHNOLOGIES LLC &copy 2005-
                                                    <script>
                                                        document.write(new Date().getFullYear())
                                                    </script>
                                                </p>
                                            </nav>
                                        </div>
                                    </footer>
                                </div>
                            </div>
                            
<!--   Core JS Files   -->
<script src="../assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>

<script src="../assets/js/plugins/bootstrap-table.js"></script>
<!--  DataTable Plugin -->
<script src="../assets/js/plugins/jquery.dataTables.min.js"></script>
<!--  Full Calendar   -->
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="../assets/js/light-bootstrap-dashboard.js?v=2.0.1" type="text/javascript"></script>
<!-- Light Dashboard DEMO methods, don't include it in your project! -->
<script src="../assets/js/demo.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        // demo.showNotification();

        // demo.initVectorMap();

    });
</script>
